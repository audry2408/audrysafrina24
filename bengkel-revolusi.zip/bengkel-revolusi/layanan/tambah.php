<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
  header("Location: ../login/login.php");
  exit();
}
include '../koneksi.php';

$success = "";
$error = "";

if (isset($_POST['simpan'])) {
  $nama = $_POST['nama'];
  $deskripsi = $_POST['deskripsi'];
  $harga = $_POST['harga'];

  if ($nama && $deskripsi && $harga) {
    $query = "INSERT INTO layanan (nama, deskripsi, harga) VALUES ('$nama', '$deskripsi', '$harga')";
    if (mysqli_query($koneksi, $query)) {
      $success = "Layanan berhasil ditambahkan!";
    } else {
      $error = "Gagal menambahkan layanan: " . mysqli_error($koneksi);
    }
  } else {
    $error = "Semua field wajib diisi.";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Layanan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card">
    <div class="card-header bg-primary text-white">
      Tambah Layanan Baru
    </div>
    <div class="card-body">
      <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
        <script>
          setTimeout(() => {
            window.location.href = 'index.php';
          }, 1500);
        </script>
      <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="mb-3">
          <label for="nama" class="form-label">Nama Layanan</label>
          <input type="text" class="form-control" name="nama" id="nama" required>
        </div>
        <div class="mb-3">
          <label for="deskripsi" class="form-label">Deskripsi</label>
          <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3" required></textarea>
        </div>
        <div class="mb-3">
          <label for="harga" class="form-label">Harga (Rp)</label>
          <input type="number" class="form-control" name="harga" id="harga" required>
        </div>
        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>
