<?php
session_start();
include '../koneksi.php';

// Cek login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
  header("Location: ../login/login.php");
  exit();
}

// Ambil ID user dari session
$id_user = $_SESSION['id'] ?? null;
if (!$id_user) {
  echo "ID user tidak ditemukan di session.";
  exit();
}

// Ambil histori berdasarkan user dari tabel histori + pesanan + keterangan
$query = "
  SELECT h.tanggal, p.nama_layanan, k.status 
  FROM histori h
  JOIN pesanan p ON h.id_pesanan = p.id
  JOIN keterangan k ON h.id_keterangan = k.id
  WHERE p.id_user = '$id_user'
  ORDER BY h.tanggal DESC
";

$histori = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Histori Layanan Anda</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
  <h3 class="mb-4">Histori Layanan Anda</h3>
  <table class="table table-bordered">
    <thead class="table-success">
      <tr>
        <th>No</th>
        <th>Nama Layanan</th>
        <th>Status</th>
        <th>Tanggal</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $no = 1;
    if ($histori && mysqli_num_rows($histori) > 0) {
      while ($row = mysqli_fetch_assoc($histori)) :
    ?>
      <tr>
        <td><?= $no++; ?></td>
        <td><?= htmlspecialchars($row['nama_layanan']); ?></td>
        <td><?= htmlspecialchars($row['status']); ?></td>
        <td><?= htmlspecialchars($row['tanggal']); ?></td>
      </tr>
    <?php endwhile;
    } else {
      echo "<tr><td colspan='4'>Belum ada histori layanan.</td></tr>";
    }
    ?>
    </tbody>
  </table>
  <a href="../customer/dashboard.php" class="btn btn-secondary">Kembali</a>
</div>
</body>
</html>
