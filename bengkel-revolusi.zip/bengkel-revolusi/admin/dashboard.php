<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
  header("Location: ../login/login.php");
  exit();
}
include '../koneksi.php';

// Notifikasi jika ada
$notif = $_GET['notif'] ?? '';

// Filter pencarian
$search = $_GET['search'] ?? '';
$min = $_GET['min'] ?? '';
$max = $_GET['max'] ?? '';

$query = "SELECT * FROM layanan WHERE 1";
if ($search != '') {
  $query .= " AND nama_layanan LIKE '%$search%'";
}
if ($min !== '' && is_numeric($min)) {
  $query .= " AND harga >= $min";
}
if ($max !== '' && is_numeric($max)) {
  $query .= " AND harga <= $max";
}
$layanan = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin - Bengkel Las</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #f4f6f9; }
    .navbar { background-color: #0d6efd; }
    .navbar-brand, .nav-link, .text-white { color: #fff !important; }
    .card { box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    .table-responsive { margin-top: 30px; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg px-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin - Revolusi Jaya Mandiri</a>
    <div class="d-flex">
      <a href="../logout.php" class="btn btn-danger">
        <i class="bi bi-box-arrow-right"></i> Logout
      </a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Data Layanan</h5>
          <p class="card-text">Kelola layanan bengkel</p>
          <a href="#layanan-section" class="btn btn-primary">Lihat</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Data Pesanan</h5>
          <p class="card-text">Kelola semua pesanan masuk</p>
          <a href="../pesanan/index.php" class="btn btn-primary">Lihat</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-center">
        <div class="card-body">
          <h5 class="card-title">Histori Pengerjaan</h5>
          <p class="card-text">Riwayat pekerjaan selesai</p>
          <a href="../histori/index.php" class="btn btn-primary">Lihat</a>
        </div>
      </div>
    </div>
  </div>

  <?php if ($notif): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <?= htmlspecialchars($notif) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card mb-4">
    <div class="card-body">
      <form class="row row-cols-lg-auto g-3" method="get">
        <div class="col-12">
          <input type="text" name="search" class="form-control" placeholder="Cari nama layanan" value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-12">
          <input type="number" name="min" class="form-control" placeholder="Harga Min" value="<?= htmlspecialchars($min) ?>">
        </div>
        <div class="col-12">
          <input type="number" name="max" class="form-control" placeholder="Harga Max" value="<?= htmlspecialchars($max) ?>">
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-secondary">Filter</button>
        </div>
      </form>
    </div>
  </div>

  <div id="layanan-section" class="table-responsive">
    <h4>Kelola Data Layanan</h4>
    <a href="../layanan/tambah.php" class="btn btn-success mb-3">+ Tambah Layanan</a>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>Nama Layanan</th>
          <th>Deskripsi</th>
          <th>Harga (Rp)</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($layanan)) : ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['nama_layanan']) ?></td>
            <td><?= htmlspecialchars($row['deskripsi']) ?></td>
            <td><?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td>
              <a href="../layanan/edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="../layanan/hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus layanan ini?')">Hapus</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
